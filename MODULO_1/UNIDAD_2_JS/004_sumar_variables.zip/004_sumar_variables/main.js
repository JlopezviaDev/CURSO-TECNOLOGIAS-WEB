let num1 = parseInt(prompt("Introduce un número"));
document.write(`Número introducido: ${num1}<br>`);
let num2 = parseInt(prompt("Intrpoduce otro número"));
document.write(`\n Número introducido: ${num2}<br>`);
let suma = num1 + num2;
document.write(`\n Suma: ${suma}`);