let edadPerro = parseInt(prompt("Introduce la edad de tu perro"));
let edadPerroHumana = edadPerro * 7;
document.write(`Edad del perro: ${edadPerro} años.<br>`);
document.write(`La edad del perro en años humanos es ${edadPerroHumana} años.`);